namespace Expenses
{
    public record Expense(int Cost, string Title, string Description);
}