﻿namespace Model
{
    public enum SkillEnum
    {
        Strength,
        Intelligence,
        Charisma,
    }
}