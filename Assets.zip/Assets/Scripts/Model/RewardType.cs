﻿namespace Model
{
    public enum RewardType
    {
        Money,
        Family,
        StrengthXp,
        IntelligenceXp,
        CharismaXp,
    }
}