﻿namespace Jobs
{
    public class BackgroundJob : Job
    {
        public int cooldownInHours;
    }
}